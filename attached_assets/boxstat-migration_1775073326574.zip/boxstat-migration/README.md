# Boxstat Migration Tool

Drop-in migration wizard for moving existing org members into Boxstat.
Built for the PERN stack: PostgreSQL + Express + React + Node, TypeScript end-to-end.

---

## Files

```
shared/types/migration.ts                          ← shared TS types (client + server)
client/src/components/migration/MigrationWizard.tsx ← React wizard component
server/routes/migration.ts                          ← Express API routes
server/emails/inviteEmail.ts                        ← Resend email template
```

---

## Integration steps

### 1. Shared types
Copy `shared/types/migration.ts` into your existing shared types directory.
If your monorepo uses a different path, update the import in the component and route accordingly.

### 2. Frontend component

Copy `MigrationWizard.tsx` into `client/src/components/migration/`.

Use it on any admin page:

```tsx
import { MigrationWizard } from "@/components/migration/MigrationWizard";

export default function MigrationPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-medium mb-2">Migrate your organization</h1>
      <p className="text-muted-foreground mb-8">
        Import existing members and send them Boxstat invite emails.
      </p>
      <MigrationWizard
        organizationId={currentOrg.id}
        organizationName={currentOrg.name}
        onComplete={(result) => console.log("Done:", result)}
      />
    </div>
  );
}
```

### 3. Backend route

Copy `server/routes/migration.ts` into your routes directory.

Register it in your main Express app (with your existing auth middleware):

```ts
import migrationRouter from "./routes/migration";

// Apply your existing org-admin auth middleware before this
app.use("/api/migration", requireOrgAdmin, migrationRouter);
```

### 4. Email template

Copy `server/emails/inviteEmail.ts` into your emails directory.

Make sure `RESEND_API_KEY` and `APP_URL` are set in your `.env`:

```env
RESEND_API_KEY=re_xxxxxxxxxxxx
APP_URL=https://app.boxstat.app
EMAIL_DOMAIN=boxstat.app
```

### 5. Database schema additions

Add these columns to your `users` table via a Drizzle migration:

```ts
// In your schema file
inviteToken:       varchar("invite_token", { length: 64 }),
inviteTokenExpiry: timestamp("invite_token_expiry"),
status:            varchar("status", { length: 20 }).default("active"),
activatedAt:       timestamp("activated_at"),
```

And these to your `players` table:

```ts
subscriptionEndDate: date("subscription_end_date"),
parentEmail:         varchar("parent_email", { length: 255 }),
```

Run `drizzle-kit generate` and `drizzle-kit migrate` after adding these.

### 6. Claim route (frontend)

When a parent clicks the invite link they land on `/invite/:token`.
Create a simple page that calls `GET /api/migration/claim/:token` to pre-fill
their name and email, then `POST /api/migration/claim/:token` with their chosen
password to activate the account. After activation, log them in via your
existing Passport.js local strategy.

---

## Flow summary

1. Org admin opens the migration page, enters parents + players (manually or paste)
2. Clicks "Send invites" → POST /api/migration/send-invites
3. Boxstat creates pending user records (status: "invited") and player records with expiry dates
4. Resend fires one invite email per parent with a 7-day token link
5. Parent clicks link → lands on /invite/:token → sets password → account activated
6. On first login, Boxstat shows their players pre-loaded with correct expiry dates
7. When a subscription expires, Boxstat prompts renewal → Stripe captures the transaction

---

## Dependencies already in your stack

- `resend` — email sending (already installed)
- `zod` — payload validation (already installed)
- `bcrypt` — password hashing (already installed)
- `drizzle-orm` — database queries (already installed)
- All Shadcn UI components used: Button, Input, Label, Select, Badge, Alert, Textarea, Tabs

No new dependencies required.
