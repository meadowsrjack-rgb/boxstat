import { Router, Request, Response } from "express";
import { z } from "zod";
import crypto from "crypto";
import { db } from "../db"; // adjust to your drizzle instance path
import { users, players, migrationInvites } from "../db/schema"; // adjust to your schema path
import { sendMigrationInvite } from "../emails/inviteEmail";
import type { MigrationPayload, MigrationResult, InviteRecord } from "../../shared/types/migration";

const router = Router();

// ── Zod validation schemas ────────────────────────────────────────────────────

const ParentSchema = z.object({
  id: z.number(),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().default(""),
  email: z.string().email("Invalid email address"),
  phone: z.string().default(""),
});

const PlayerSchema = z.object({
  id: z.number(),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().default(""),
  parentId: z.number().nullable(),
  subscriptionEndDate: z.string().default(""),
});

const MigrationPayloadSchema = z.object({
  organizationId: z.string().min(1),
  parents: z.array(ParentSchema).min(1, "At least one parent is required"),
  players: z.array(PlayerSchema),
});

// ── Helper: parse MM/DD/YYYY to Date ─────────────────────────────────────────

function parseExpiry(mmddyyyy: string): Date | null {
  if (!mmddyyyy) return null;
  const [month, day, year] = mmddyyyy.split("/").map(Number);
  if (!month || !day || !year) return null;
  const d = new Date(year, month - 1, day);
  return isNaN(d.getTime()) ? null : d;
}

// ── POST /api/migration/send-invites ─────────────────────────────────────────
// Expects: MigrationPayload
// Auth: must be an org admin (middleware applied in your main router)

router.post("/send-invites", async (req: Request, res: Response) => {
  // Validate payload
  const parsed = MigrationPayloadSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: "Invalid payload",
      details: parsed.error.flatten(),
    });
  }

  const payload = parsed.data as MigrationPayload;
  const result: MigrationResult = { invited: 0, skipped: 0, errors: [] };

  // Get org name for email subject (adjust to your orgs table)
  let orgName = "Your organization";
  try {
    const org = await db.query.organizations.findFirst({
      where: (o, { eq }) => eq(o.id, payload.organizationId),
    });
    if (org?.name) orgName = org.name;
  } catch {
    // Non-fatal — fall back to generic org name
  }

  // Build invite records — one per parent with their players nested
  const inviteRecords: InviteRecord[] = payload.parents.map((parent) => ({
    parent,
    players: payload.players.filter((p) => p.parentId === parent.id),
  }));

  // Process each family
  for (const record of inviteRecords) {
    const { parent, players: kids } = record;

    if (!parent.email) {
      result.skipped++;
      continue;
    }

    try {
      // Check if user already exists
      const existing = await db.query.users.findFirst({
        where: (u, { eq }) => eq(u.email, parent.email.toLowerCase()),
      });

      // Generate a secure invite token
      const inviteToken = crypto.randomBytes(32).toString("hex");
      const tokenExpiry = new Date();
      tokenExpiry.setDate(tokenExpiry.getDate() + 7); // 7-day invite link

      if (existing) {
        // User exists — just link players if not already linked
        // and update their invite token so the email still works
        await db
          .update(users)
          .set({ inviteToken, inviteTokenExpiry: tokenExpiry })
          .where(eq(users.id, existing.id));
      } else {
        // Create a pending user record — no password yet
        await db.insert(users).values({
          firstName: parent.firstName,
          lastName: parent.lastName,
          email: parent.email.toLowerCase(),
          phone: parent.phone || null,
          role: "parent",
          organizationId: payload.organizationId,
          status: "invited",           // account not active until claimed
          inviteToken,
          inviteTokenExpiry: tokenExpiry,
          createdAt: new Date(),
        });
      }

      // Create pending player records linked to this parent
      for (const kid of kids) {
        const expiryDate = parseExpiry(kid.subscriptionEndDate);

        await db.insert(players).values({
          firstName: kid.firstName,
          lastName: kid.lastName,
          parentEmail: parent.email.toLowerCase(),
          organizationId: payload.organizationId,
          subscriptionEndDate: expiryDate,
          status: expiryDate && expiryDate < new Date() ? "expired" : "active",
          createdAt: new Date(),
        });
      }

      // Send the invite email via Resend
      const emailResult = await sendMigrationInvite(record, inviteToken, orgName);

      if (!emailResult.success) {
        result.errors.push(`${parent.email}: ${emailResult.error}`);
        result.skipped++;
      } else {
        result.invited++;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      result.errors.push(`${parent.email}: ${msg}`);
      result.skipped++;
    }
  }

  return res.json(result);
});

// ── GET /api/migration/claim/:token ──────────────────────────────────────────
// Called when a parent clicks their invite link.
// Validates the token, returns the pending user data so the
// frontend can pre-fill the account setup form.

router.get("/claim/:token", async (req: Request, res: Response) => {
  const { token } = req.params;

  const user = await db.query.users.findFirst({
    where: (u, { eq }) => eq(u.inviteToken, token),
  });

  if (!user) {
    return res.status(404).json({ error: "Invite link not found or already used." });
  }

  if (!user.inviteTokenExpiry || user.inviteTokenExpiry < new Date()) {
    return res.status(410).json({ error: "This invite link has expired. Ask your org admin to resend." });
  }

  const linkedPlayers = await db.query.players.findMany({
    where: (p, { eq }) => eq(p.parentEmail, user.email),
  });

  return res.json({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    phone: user.phone,
    players: linkedPlayers,
  });
});

// ── POST /api/migration/claim/:token ─────────────────────────────────────────
// Parent submits their password to activate their account.

router.post("/claim/:token", async (req: Request, res: Response) => {
  const { token } = req.params;
  const { password } = req.body;

  if (!password || password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const user = await db.query.users.findFirst({
    where: (u, { eq }) => eq(u.inviteToken, token),
  });

  if (!user) {
    return res.status(404).json({ error: "Invite link not found or already used." });
  }

  if (!user.inviteTokenExpiry || user.inviteTokenExpiry < new Date()) {
    return res.status(410).json({ error: "This invite link has expired." });
  }

  // Hash password using whatever you use in the rest of the app (bcrypt assumed)
  const bcrypt = await import("bcrypt");
  const passwordHash = await bcrypt.hash(password, 12);

  await db
    .update(users)
    .set({
      passwordHash,
      status: "active",
      inviteToken: null,
      inviteTokenExpiry: null,
      activatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  return res.json({ success: true, email: user.email });
});

export default router;
